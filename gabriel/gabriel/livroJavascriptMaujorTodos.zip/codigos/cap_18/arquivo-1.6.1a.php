<?php include("../includes-arquivos/doc-meta.inc.php"); ?>
<link href="../estilos.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="ajaxtext.js"></script>
</head>
<body>
<div id="tudo">
<div id="conteudo">
<h1>Exemplo de requisi&ccedil;&atilde;o TXT</h1>
<a href="mensagem.txt" onClick="requisitar(this.href); return false;">Requisitar o arquivo <strong>mensagem.txt</strong></a>

<div id="nav">Arquivos exemplo do livro do Maujor | AJAX com jQuery: <a href="arquivo-1.2.1a.php">&laquo; anterior</a> | <a href="arquivo-1.6.2a.php">pr&oacute;ximo &raquo;</a> </div>

</div>
</div>
</body>
</html>
